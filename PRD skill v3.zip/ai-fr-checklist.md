# AI Functional Requirements Checklist

## Purpose
This checklist ensures that AI-powered features have complete functional requirements covering user interaction, data handling, failure modes, and transparency. Use this when authoring Section 6.2 (AI Functional Requirements) of an AI PRD.

---

## How to Use This Checklist

**Timing:** Use when authoring AI Functional Requirements (Section 6.2)

**Approach:** Work through each category conversationally with the PM
- Present each item as a question
- Listen to PM's answer
- Document in PRD
- Flag if critical items are missing

**Remember:** Not all items apply to every AI solution. Use judgment based on:
- Solution type (conversational vs. one-shot vs. agent)
- Context from UX flows
- Complexity of the feature

---

## Category 1: User Interaction & Feedback
**Always check these items**

### Input Method
**Question to PM:** "How will users provide input to the AI?"

**Capture:**
- Natural language (text/voice)?
- Structured inputs (forms, dropdowns)?
- File uploads?
- Combination?

**Document in PRD:** AI-FR-1

---

### Processing Indication
**Question to PM:** "How will users know the AI is working on their request?"

**Capture:**
- Loading spinner?
- "Thinking..." indicator?
- Progress bar?
- Streaming response (tokens appear as generated)?

**Document in PRD:** AI-FR-2

---

### Feedback Mechanism
**Question to PM:** "How can users provide feedback on AI outputs?"

**Capture:**
- Thumbs up/down?
- Star rating?
- Detailed feedback form?
- Flag inappropriate/incorrect?
- Report button?

**Flag if missing:** Feedback is critical for AI improvement

**Document in PRD:** AI-FR-3

---

### Output Editing
**Question to PM:** "Can users edit or refine what the AI generates?"

**Capture:**
- Direct editing in place?
- Request modifications via follow-up?
- Accept/reject/modify workflow?
- Copy to clipboard for external editing?

**Document in PRD:** AI-FR-4

---

### Regeneration
**Question to PM:** "Can users ask the AI to try again if they don't like the output?"

**Capture:**
- Regenerate button?
- "Try another response" option?
- Adjust and regenerate?
- Limit on regenerations?

**Document in PRD:** AI-FR-5

---

## Category 2: Data & Context
**Always check these items (some conditional)**

### Data Sources
**Question to PM:** "What data does the AI need access to?"

**Capture:**
- User's own data (files, profile)?
- Company databases?
- External APIs?
- Public data sources?
- Real-time data?

**Flag if missing:** Critical for scoping and dependencies

**Document in PRD:** AI-FR-6

---

### Access Controls
**Question to PM:** "What permissions or authorization are required?"

**Capture:**
- User must be authenticated?
- Role-based access (admin, user, etc.)?
- Data-level permissions (can only access own data)?
- Audit trail requirements?

**Flag if missing:** Security concern

**Document in PRD:** AI-FR-7

---

### Context Retention (CONDITIONAL)
**Check if:** Solution is conversational (chat, multi-turn interaction)

**Question to PM:** "How much conversation history does the AI remember?"

**Capture:**
- Session-based (cleared when user leaves)?
- Persistent across sessions?
- How many previous turns?
- How long retained?

**Skip if:** One-shot or stateless AI interaction

**Document in PRD:** AI-FR-8

---

### User Data Usage
**Question to PM:** "What user data will the AI use to personalize or inform its responses?"

**Capture:**
- User profile information?
- Preferences/settings?
- Usage history?
- Location?
- None (generic responses)?

**Document in PRD:** AI-FR-9

---

### External System Access
**Question to PM:** "Does the AI need to access external systems or APIs?"

**Capture:**
- Which systems (CRM, calendar, email, etc.)?
- What operations (read-only, write, both)?
- Authentication requirements?
- Real-time or batch?

**Document in PRD:** AI-FR-10

---

## Category 3: Failure States & Fallbacks
**Always check these items - critical for reliability**

### Service Unavailable
**Question to PM:** "What should happen if the AI service is down or times out?"

**Capture:**
- Show error message?
- Queue request and retry?
- Fall back to non-AI alternative?
- Notify user and suggest coming back later?

**Flag if missing:** This WILL happen - need a plan

**Document in PRD:** AI-FR-11

---

### Task Failure
**Question to PM:** "What if the AI can't complete the task (doesn't understand, insufficient info, etc.)?"

**Capture:**
- Ask clarifying questions?
- Gracefully decline with explanation?
- Escalate to human?
- Offer alternative approach?

**Flag if missing:** AI won't always succeed - need handling

**Document in PRD:** AI-FR-12

---

### Fallback Behavior
**Question to PM:** "For each failure mode, what's the specific fallback?"

**Capture:**
- Map each failure type to specific behavior
- Ensure user experience degrades gracefully
- No dead ends or cryptic errors

**Document in PRD:** AI-FR-13

---

### User Notification
**Question to PM:** "How are users informed when something goes wrong?"

**Capture:**
- Error message wording?
- Helpful suggestions for user?
- Escalation path if needed?
- Transparency about what went wrong?

**Document in PRD:** AI-FR-14

---

## Category 4: Transparency & Explainability
**CONDITIONAL - check if relevant based on solution type**

**When to include:**
- AI makes recommendations or decisions
- AI answers questions that require trust
- AI handles sensitive topics
- Regulatory requirements for explainability

**When to skip:**
- Simple classification or extraction
- Behind-the-scenes processing
- User doesn't need to understand reasoning

---

### AI Disclosure
**Question to PM:** "Do users need to know they're interacting with AI (vs. a traditional feature)?"

**Capture:**
- Explicit "AI" badge or label?
- Explained in onboarding/help?
- Obvious from interaction pattern?
- Legal/regulatory requirement to disclose?

**Document in PRD:** AI-FR-15

---

### Reasoning Display
**Question to PM:** "Should the AI explain how it arrived at its answer or recommendation?"

**Capture:**
- Show reasoning/logic?
- Display confidence factors?
- Explain why it chose this path?
- Keep reasoning internal (black box)?

**Document in PRD:** AI-FR-16

---

### Source Citation
**Question to PM:** "Should the AI cite sources for factual claims?"

**Capture:**
- Link to source documents?
- Mention source names?
- Show excerpts?
- No citation needed?

**Common for:** Research assistants, Q&A bots, summarization

**Document in PRD:** AI-FR-17

---

### Confidence Display
**Question to PM:** "Should users see how confident the AI is in its output?"

**Capture:**
- Confidence score (e.g., 85%)?
- Qualitative indicators (high/medium/low)?
- Color coding or visual cues?
- Hidden from user?

**Document in PRD:** AI-FR-18

---

### Data Visibility
**Question to PM:** "Can users see what data the AI used to generate its response?"

**Capture:**
- Show data sources?
- List documents referenced?
- Display search results used?
- Keep data usage opaque?

**Common for:** Data analysis tools, research assistants

**Document in PRD:** AI-FR-19

---

## Validation & Review

**After completing checklist:**

✅ **Mark complete** if all relevant items covered  
⚠️ **Flag gaps** if critical items missing:
- No feedback mechanism
- No failure handling
- No access controls defined
- Missing data sources

**Inform PM:**
```
"I've worked through the AI functional requirements checklist. We've covered:
✅ User interaction & feedback
✅ Data & context
✅ Failure states & fallbacks
[✅/⚠️] Transparency & explainability

[If gaps]
We should address: [list critical gaps]

[If complete]
All AI-specific behaviors are documented. Ready to move to Non-Functional Requirements."
```

---

## Common Patterns by AI Type

**For quick reference, here are typical requirements by solution type:**

### One-Shot AI (Classification, Extraction, Simple Generation)
- **Essential:** Input, processing indication, output editing, failure handling
- **Optional:** Feedback (nice-to-have), regeneration
- **Skip:** Context retention, reasoning display

### Conversational AI (Chat, Q&A Bot)
- **Essential:** All Category 1, context retention, all Category 3, source citation
- **Nice-to-have:** Reasoning display, confidence
- **Check for:** Data sources, external access

### AI Agent (Autonomous, Multi-step)
- **Essential:** All categories except sometimes explainability
- **Critical:** Failure handling (more complex), data sources, access controls
- **Nice-to-have:** Show reasoning/steps taken

### AI with MCP (Tool-using AI)
- **Essential:** All Category 1, Category 2 (especially external access), Category 3
- **Critical:** Access controls, failure handling for each tool
- **Nice-to-have:** Transparency about which tools used

---

## Notes

- **Be conversational:** Don't read checklist items verbatim - ask natural questions
- **Use judgment:** Not everything applies to every AI feature
- **Flag critical gaps:** Don't let PM skip essential items (feedback, failure handling, access controls)
- **Trust PM:** If they say something doesn't apply, believe them (after confirming)
- **Document clearly:** Requirements should be specific and testable
