# AI Non-Functional Requirements Checklist

## Purpose
This checklist ensures AI-powered features have appropriate quality, performance, cost, regional, and compliance requirements. Use this when authoring Section 7.2 (AI Quality & Performance Requirements) of an AI PRD.

---

## How to Use This Checklist

**Timing:** Use when authoring AI Non-Functional Requirements (Section 7.2)

**Approach:** 
- Not all items are mandatory - use SME judgment
- Some categories are nice-to-have unless red flags detected
- Flag critical gaps based on context

**Priority levels:**
- 🔴 **Must have** - Always required
- 🟡 **Flag if relevant** - Required when conditions met
- 🟢 **Nice to have** - Optional, ask if PM wants to include

---

## Category 1: Performance & Latency
**🟢 Nice to have (unless critical to UX)**

### When to include:
- User-facing real-time interactions
- Latency impacts user experience significantly
- PM mentions speed concerns

### When to skip:
- Background/batch processing
- PM says "performance isn't a concern"
- Async operations where user doesn't wait

---

### AI Response Time
**Question to PM:** "What's an acceptable response time for the AI?"

**Capture:**
- Target latency (e.g., <3s for p95)
- User tolerance threshold
- Different expectations for simple vs. complex queries

**Consider:**
- Simple queries may need faster responses
- Complex analysis can tolerate longer waits
- Set realistic expectations (AI is typically slower than traditional code)

**Document in PRD:** Performance & Latency table

---

### First Token Latency (CONDITIONAL)
**Check if:** Streaming responses (tokens appear as generated)

**Question to PM:** "How quickly should the first token appear?"

**Capture:**
- Target for first token (e.g., <500ms)
- Important for perceived responsiveness

**Skip if:** Not streaming, batch responses

**Document in PRD:** Performance & Latency table

---

### Timeout Threshold
**Question to PM:** "How long should we wait before giving up and showing an error?"

**Capture:**
- Maximum wait time before timeout
- Fallback behavior when timeout occurs
- Balance between giving AI time and keeping user engaged

**Document in PRD:** Performance & Latency table

---

### Performance Under Load
**Question to PM:** "How many concurrent AI requests should the system handle?"

**Capture:**
- Expected concurrent users
- Peak usage scenarios
- Scale requirements

**Document in PRD:** Performance & Latency table

---

## Category 2: Cost & Budget
**🟡 Flag if obviously expensive - otherwise optional**

### When to flag as required:
- High volume usage expected
- Complex AI operations (large context, many tokens)
- Real-time/streaming usage
- Multiple AI calls per user interaction
- PM mentions cost concerns

### When it's optional:
- Low volume usage
- Simple AI operations
- PM explicitly says "cost isn't a concern"

---

### Monthly Budget
**Question to PM:** "Do you have a monthly budget for AI service costs?"

**Capture:**
- Total monthly budget for AI services
- Cost per user if applicable
- Whether this needs approval

**Flag if:** High volume expected + no budget discussion

**Document in PRD:** Cost & Budget table

---

### Per-Request Limit
**Question to PM:** "Should we limit the cost or tokens per request?"

**Capture:**
- Maximum tokens per request
- Maximum cost per interaction
- Why limit exists (budget control, abuse prevention)

**Flag if:** Open-ended generation with no limits (cost risk)

**Document in PRD:** Cost & Budget table

---

### Rate Limiting
**Question to PM:** "Should we limit how many AI requests a user can make?"

**Capture:**
- Requests per user per hour/day
- Reason (cost control, abuse prevention, fair usage)
- What happens when limit hit

**Flag if:** Public-facing with no rate limits (abuse risk)

**Document in PRD:** Cost & Budget table

---

### Budget Exceeded Behavior
**Question to PM:** "What should happen if we hit budget limits?"

**Capture:**
- Throttle new requests?
- Queue and process slower?
- Notify admin?
- Graceful degradation?

**Document in PRD:** Cost & Budget table

---

## Category 3: Regional & Language Support
**🔴 Must have - ALWAYS required**

This is critical for any AI feature. Always discuss with PM.

---

### Supported Regions
**Question to PM:** "Which regions/countries need to be supported?"

**Capture:**
- List of regions (e.g., US, EU, APAC)
- Support status for each (Supported, Future, Not supported)
- Any region-specific requirements

**Flag if missing:** This is required - cannot skip

**Common regions to ask about:**
- North America (US, Canada)
- Europe (EU, UK)
- Asia-Pacific (APAC)
- Latin America (LATAM)
- Middle East & Africa (MEA)

**Document in PRD:** Regional & Language Support table

---

### Supported Languages
**Question to PM:** "Which languages need to be supported?"

**Capture:**
- List of languages
- Support status for each
- Quality expectations (native-level vs. basic)

**Flag if missing:** Required if product is international

**Document in PRD:** Regional & Language Support table

---

### Unsupported Regions/Languages Behavior
**Question to PM:** "What happens when users are in unsupported regions or use unsupported languages?"

**Capture:**
- Error message?
- Graceful degradation to English?
- Feature disabled?
- Alternative flow?

**Flag if missing:** Need clear handling

**Document in PRD:** Regional & Language Support table

---

### Data Residency
**Question to PM:** "Are there data residency requirements for any regions?"

**Capture:**
- Which regions require data to stay in-region
- Why (legal, compliance, performance)
- Impact on architecture

**Flag if:** EU, China, or other regions with strict data laws

**Document in PRD:** Regional & Language Support table

---

## Category 4: Safety & Compliance
**🟡 Flag if red flags detected - otherwise optional**

### When to flag as required (RED FLAGS):
- ⚠️ Processing sensitive data (PII, financial, health)
- ⚠️ Cross-border data movement
- ⚠️ Regulated industry (healthcare, finance, government)
- ⚠️ Long-term data storage
- ⚠️ Children's data (COPPA)
- ⚠️ Employee data

### When it's optional:
- Public/non-sensitive data only
- No regulatory concerns
- Transient processing (no storage)
- PM confirms no compliance requirements

---

### Regulatory Compliance
**Question to PM:** "Are there any regulatory requirements we need to meet?"

**Capture:**
- GDPR (EU data protection)
- CCPA (California privacy)
- HIPAA (health data)
- SOC 2 (security standards)
- Industry-specific regulations

**Flag if:** Red flags detected

**Document in PRD:** Safety & Compliance table

---

### Data Classification
**Question to PM:** "How sensitive is the customer data being used?"

**Capture:**
- Classification level (adapt to company's system)
  - Public
  - Internal
  - Confidential
  - Restricted/Highly Confidential
- Why this classification

**Common systems:**
- Diligent uses C1-C5
- Others use Public/Internal/Confidential/Restricted
- Some use data sensitivity tiers

**Flag if:** High-sensitivity data without classification

**Document in PRD:** Safety & Compliance table

---

### Data Access Type
**Question to PM:** "Are we storing customer data or just processing it?"

**Capture:**
- Storing permanently?
- Processing transiently?
- Caching temporarily?
- Passing through to third-party?

**Flag if:** Storing high-sensitivity data long-term

**Document in PRD:** Safety & Compliance table

---

### Data Retention
**Question to PM:** "How long do we keep customer data?"

**Capture:**
- Retention period (days, months, indefinite)
- Why we need to keep it
- Deletion/purging process

**Flag if:** Long retention + sensitive data

**Document in PRD:** Safety & Compliance table

---

### PII Handling
**Question to PM:** "How should Personally Identifiable Information be handled?"

**Capture:**
- PII types involved (names, emails, SSN, etc.)
- Redaction before AI processing?
- Encryption requirements?
- Access controls?

**Flag if:** PII being processed without handling plan

**Document in PRD:** Safety & Compliance table

---

### Audit Logging
**Question to PM:** "What needs to be logged for audit purposes?"

**Capture:**
- What to log (requests, responses, user actions)
- Retention period for logs
- Who can access logs
- Why logging needed

**Flag if:** Compliance requires audit trail + no logging plan

**Document in PRD:** Safety & Compliance table

---

## Category 5: Quality & Accuracy
**🔴 Must have - ALWAYS required**

Every AI feature needs quality standards. Don't skip this.

---

### Task Completion Rate
**Question to PM:** "What percentage of tasks should the AI successfully complete?"

**Capture:**
- Target completion rate (e.g., >90%)
- What counts as "completion"
- Acceptable failure rate

**Flag if missing:** Required - need quality bar

**Document in PRD:** Quality & Accuracy table

---

### Accuracy
**Question to PM:** "How accurate does the AI need to be?"

**Capture:**
- Target accuracy (e.g., >95% on test set)
- How accuracy is measured
- What counts as "correct"

**Flag if missing:** Required for any AI that makes predictions/decisions

**Document in PRD:** Quality & Accuracy table

---

### Error Rate
**Question to PM:** "What error rate is acceptable?"

**Capture:**
- Maximum error rate (e.g., <5%)
- Types of errors to track
- Severity of different error types

**Document in PRD:** Quality & Accuracy table

---

### False Positives / False Negatives
**Question to PM:** "For classification/detection, which is worse - false positives or false negatives?"

**Capture:**
- False positive rate target
- False negative rate target
- Trade-off between them
- Business impact of each

**Check if applicable:** Classification, detection, filtering tasks

**Document in PRD:** Quality & Accuracy table

---

### Acceptance Criteria
**Question to PM:** "What level of quality is 'good enough' to ship?"

**Capture:**
- Minimum quality bar to launch
- Success metrics for go/no-go
- Who approves quality assessment

**Flag if missing:** Required - need launch criteria

**Document in PRD:** Quality & Accuracy section

---

### Error/Mistake Handling
**Question to PM:** "How are errors or mistakes detected and handled?"

**Capture:**
- Error detection mechanism
- User reporting of mistakes
- Correction/learning process
- Response to mistakes

**Document in PRD:** Quality & Accuracy section

---

### Testing Approach
**Question to PM:** "How will we test the AI before launch?"

**Capture:**
- Test dataset (size, composition)
- Evaluation criteria
- Success threshold
- Testing cadence (once vs. ongoing)

**Flag if missing:** Required - can't ship without testing

**Document in PRD:** Quality & Accuracy section

---

## Validation & Review

**After completing checklist:**

### Required Items Check:
- ✅ Regional & Language Support (MUST HAVE)
- ✅ Quality & Accuracy (MUST HAVE)

### Conditional Items Check:
- 🟡 Performance & Latency (if user-facing real-time)
- 🟡 Cost & Budget (if high volume or complex)
- 🟡 Safety & Compliance (if red flags detected)

### Red Flags Assessment:

**Ask yourself:**
- Is this processing sensitive data? → Need Safety & Compliance
- Is this high-volume or expensive? → Need Cost & Budget
- Is latency critical to UX? → Need Performance targets
- Is this regulated industry? → Need Compliance

**Inform PM:**
```
"I've worked through the AI non-functional requirements checklist:

✅ Regional & Language Support: [Covered/Needs attention]
✅ Quality & Accuracy: [Covered/Needs attention]

[If red flags]
⚠️ I noticed we're [processing PII / high volume / regulated industry]. 
   We should address: [Safety & Compliance / Cost & Budget]

[If optional items discussed]
✅ Performance targets defined
✅ Cost controls in place

[If complete]
All AI quality requirements are documented. Ready to move to Dependencies."
```

---

## SME Judgment Guide

**When to push back:**
- No quality metrics defined → "We need to define what 'good enough' means"
- Sensitive data + no classification → "How sensitive is this data?"
- No regional support discussion → "Which regions need to work?"
- No testing approach → "How will we know it's ready to launch?"

**When to accept "not needed":**
- PM says performance isn't a concern → Trust them
- PM confirms cost isn't constrained → Accept it
- Simple use case, no compliance issues → Don't force it

**Red flags that MUST be addressed:**
- Processing PII without discussing handling
- International feature without regional support
- No quality acceptance criteria
- Storing sensitive data without retention policy

---

## Notes

- **Be conversational:** Don't read checklist verbatim
- **Use SME judgment:** Not everything is mandatory
- **Flag red flags:** Don't let critical items slip
- **Trust PM on constraints:** If they say cost/performance isn't a concern, believe them
- **Document clearly:** NFRs should be specific and measurable
- **Balance thoroughness with pragmatism:** Don't over-engineer small features
