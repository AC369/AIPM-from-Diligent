# [Feature Name] - Product Requirements Document

---
```yaml
prd_type: standard
status: draft
product_area: [Product/App Name]
related_documents: []
author: [PM Name]
created_date: YYYY-MM-DD
last_updated: YYYY-MM-DD
target_quarter: [Q1 2025]
confluence_link: ""
github_path: ""
```
---

## 1. Document Info

**Feature Name:** [Name]  
**Product/App:** [Product this belongs to]  
**Type:** [New Feature / Incremental Enhancement]  
**Extends:** [Parent feature name, if incremental] *(optional)*

**Key Stakeholders:**
- PM: [Name]
- Engineering Lead: [Name]
- Design: [Name]
- Other: [Names]

---

## 2. Problem Statement

### Business Context
[2-3 sentences: What business problem are we solving? Why does this matter to the company?]

### Objectives
[What are we trying to achieve? Tie to company/team goals if applicable]

1. [Primary objective]
2. [Secondary objective]
3. [Additional objective if needed]

### Target Users (Personas)
**Primary Persona:** [Name/Role]
- [Key characteristics]
- [Current pain points]
- [Goals/motivations]

**Secondary Persona:** [Name/Role] *(if applicable)*
- [Key characteristics]
- [Current pain points]

### Problem Description
[3-6 sentences using Working Backwards pattern:
- WHO: Which users/personas face this problem
- CONTEXT: What situation triggers this problem
- PAIN: What specific problems/frustrations exist (with evidence if available)
- IMPACT: What's the cost of NOT solving this (customer + business impact)]

**Out of Scope:** [What we're explicitly NOT building]

---

## 3. Success Metrics

**How will we measure success?**

| Metric | Baseline | Target | Timeline | Measurement Method |
|--------|----------|--------|----------|-------------------|
| [Primary metric] | [Current state] | [Goal] | [When] | [How we'll track] |
| [Secondary metric] | [Current state] | [Goal] | [When] | [How we'll track] |

**Leading Indicators:** [Early signals that we're on track]
- [Metric 1]: [Target]
- [Metric 2]: [Target]

---

## 4. User Experience

### User Stories / Use Cases

**Primary Use Case:**
As a [persona], I want to [action], so that [benefit/outcome].

**Acceptance Criteria:**
- [Criterion 1]
- [Criterion 2]
- [Criterion 3]

**Additional Use Cases:** *(if applicable)*
- [Use case 2]
- [Use case 3]

### User Flow
[Describe the happy path - what does the user do step by step?]

1. User [action]
2. System [response]
3. User [next action]
4. System [final outcome]

**Alternative Flows:** *(if applicable)*
- Error case: [What happens if X goes wrong]
- Edge case: [What happens if Y]

---

## 5. UX/Design Notes

**Design Link:** [Figma/Sketch link if available]

**Key Design Considerations:**
- [Visual/interaction requirement 1]
- [Visual/interaction requirement 2]
- [Accessibility consideration]

**Design Assets Needed:**
- [ ] [Asset 1]
- [ ] [Asset 2]

*(Mark as "N/A" if no UX changes for incremental features)*

---

## 6. Functional Requirements

| Req # | Capability | Description | Priority | Acceptance Criteria |
|-------|------------|-------------|----------|-------------------|
| FR-1 | [Name] | [What it does] | Must-have | [How to verify it works] |
| FR-2 | [Name] | [What it does] | Must-have | [How to verify it works] |
| FR-3 | [Name] | [What it does] | Should-have | [How to verify it works] |
| FR-4 | [Name] | [What it does] | Nice-to-have | [How to verify it works] |

**Notes:**
- Requirements describe WHAT, not HOW (let engineering decide implementation)
- Prioritize: Must-have = MVP, Should-have = V1, Nice-to-have = Future
- Each requirement should be testable

---

## 7. Non-Functional Requirements

| Category | Requirement | Details |
|----------|-------------|---------|
| **Performance** | Response time | [e.g., <2s for p95] |
| **Performance** | Throughput | [e.g., 1K concurrent users] |
| **Scalability** | Growth support | [e.g., 10x users over 2 years] |
| **Security** | Authentication | [Method/service] |
| **Security** | Authorization | [RBAC rules] |
| **Data Handling** | Data sensitivity | [Classification level] |
| **Data Handling** | Data retention | [How long, where stored] |
| **Accessibility** | Standards | [e.g., WCAG 2.1 AA if UI] |
| **Reliability** | Uptime | [e.g., 99.9%] |
| **Monitoring** | Observability | [What to track/alert on] |

**Data Privacy & Compliance:**
- [Any regulatory requirements]
- [Data residency considerations if international]
- [PII handling requirements]

---

## 8. Dependencies & Rollout

### Dependencies

**Internal Dependencies:**
- [Team/feature X]: [What we need from them]
- [Service Y]: [What we need]

**External Dependencies:**
- [Third-party service]: [What we need]
- [Vendor]: [What we need]

**Technical Dependencies:**
- [Platform capability]: [What we're building on]
- [API/service]: [What we're integrating with]

### Risks & Mitigations

| Risk | Impact | Likelihood | Mitigation |
|------|--------|-----------|------------|
| [Risk 1] | [High/Med/Low] | [High/Med/Low] | [How we'll address] |
| [Risk 2] | [High/Med/Low] | [High/Med/Low] | [How we'll address] |

### Rollout Plan

**Phase 1:** [Date/timeframe]
- [What ships]
- [To whom]

**Phase 2:** [Date/timeframe] *(if phased rollout)*
- [What ships]
- [To whom]

**Launch Checklist:**
- [ ] Requirements complete
- [ ] Design approved
- [ ] Implementation complete
- [ ] QA complete
- [ ] Security review (if required)
- [ ] Documentation complete
- [ ] Monitoring/alerts configured
- [ ] Rollback plan ready

---

## 9. Open Questions

Track unresolved items that need answers:

| # | Question | Owner | Deadline | Status |
|---|----------|-------|----------|--------|
| 1 | [Question] | [Who's responsible] | [When needed] | Open/Resolved |
| 2 | [Question] | [Who's responsible] | [When needed] | Open/Resolved |

---

## 10. Change Log

Track all changes to this PRD for audit trail:

| Date | Section | Change | Reason | Author |
|------|---------|--------|--------|--------|
| [Date] | All | Initial PRD created | - | [PM Name] |
| [Date] | [Section] | [What changed] | [Why] | [Who] |

---

## 11. Appendix (Optional)

**Related Documents:**
- [Discovery Brief link]
- [Related PRD link]
- [Design spec link]
- [Technical design doc link]

**Reference Material:**
- [Schemas, data structures, or other reference info]
- [Example data or test scenarios]

**Notes:**
- [Any additional context that doesn't fit above]

---

**Status:** Draft | In Review | Approved | In Progress | Completed  
**Last Updated:** [Date]
