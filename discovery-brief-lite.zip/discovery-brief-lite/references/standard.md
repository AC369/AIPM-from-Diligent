# Discovery Brief Lite - Standard for AISDLC

## Overview

This standard defines the structure, content requirements, and best practices for creating **lightweight discovery briefs** at Diligent. 

**Why "Lite"?** Discovery briefs are lightweight validation documents (5-10 pages, 3-7 days), not comprehensive PRDs (20-30 pages, 2-4 weeks). 

**Discovery briefs are NOT PRDs.** They are lightweight validation documents that establish:
- "We did the research"
- "We validated the problem and viability"  
- "We kicked around a few ideas and landed on one we like"

Everything else (detailed requirements, user flows, designs, technical architecture, implementation planning) belongs in a **PRD** that comes after the discovery brief.

### Document Purpose

**Discovery Brief:**
- Validates the problem is real and worth solving
- Explores solution options (2-3 alternatives)
- Chooses a solution direction (high-level)
- Gets PM + UX alignment
- Typical length: 5-10 pages
- Typical effort: 3-7 days

**PRD (separate document, not covered by this skill):**
- Detailed functional requirements
- User flows and mockups (Atlas Connector)
- Technical architecture
- Implementation plan
- Gets PM + UX + ENG alignment
- Typical length: 15-30 pages
- Typical effort: 2-4 weeks

---

## Brief Structure

### Header Section (Metadata Table)

All discovery briefs must begin with a metadata table containing:

| Field | Description | Required | Values/Format |
|-------|-------------|----------|---------------|
| **Discovery Status** | Current phase of discovery | Yes | DRAFT / PROBLEM DISCOVERY / SOLUTION DISCOVERY / COMPLETE |
| **Business Unit** | Owning business unit | Yes | Platform / Risk & Audit / Boards / Entities / etc. |
| **Product** | Specific product(s) affected | Yes | Product name(s) |
| **Assigned PM** | Product Manager owner | Yes | @mention |
| **UX Team** | UX/Design team members | Optional | @mentions |
| **Strategic Goal** | Link to strategic initiative | Yes | Confluence link |
| **Product Theme** | Related product theme/epic | Optional | Jira link |

---

## Section 1: Problem Discovery

**Goal:** Define the problem, understand user needs, and validate its importance.

### 1.1 Problem Statement
- **Purpose:** Clearly articulate the problem being solved
- **Content Requirements:**
  - Concise, specific problem description (2-4 sentences)
  - User impact focus
  - Current state challenges
  - Avoid solution language
- **Example Format:**
  > "[User type] struggle to [accomplish task] because [root cause]. This results in [negative outcome], impacting [business metric/user experience]."

### 1.2 Target Users, Personas & Pain Points
- **Purpose:** Identify who is affected and how
- **Content Requirements:**
  - List of specific personas (with role descriptions)
  - Job titles and functional roles
  - Specific pain points for each persona
  - Current workarounds (if any)
- **Persona Table Format:**

| Persona Title | Role & Function | Pain Points | Relevance to Solution |
|---------------|-----------------|-------------|----------------------|
| [Title] | [Description] | [List 2-3 specific pain points] | [Why this matters] |

### 1.3 Evidence & Insights
- **Purpose:** Provide data-driven validation of the problem
- **Content Requirements:**
  - User research findings (interviews, surveys)
  - Usage statistics and metrics
  - Support ticket analysis
  - Customer feedback quotes
  - Competitive analysis (if relevant)
  - Links to research materials (Dovetail, Figma, etc.)
- **Best Practice:** Include both quantitative and qualitative data

### 1.4 Opportunity Size
- **Purpose:** Quantify the impact potential
- **Content Requirements:**
  - Number of users affected
  - Business impact (revenue, retention, efficiency)
  - Market opportunity
  - Strategic importance
- **Example Metrics:**
  - "Affects 85% of active users managing 5+ entities"
  - "Could reduce churn by 15% based on correlation analysis"
  - "Addresses #3 feature request with 247 votes"

### 1.5 Background / Context (Optional)
- **Purpose:** Provide additional context when needed
- **Content Requirements:**
  - Historical context
  - Related initiatives
  - Market trends
  - Regulatory requirements
- **When to Include:** Complex initiatives, compliance-driven features, platform changes

---

## Section 2: Solution Discovery

**Goal:** Explore potential solutions and choose a direction (HIGH-LEVEL only).

**CRITICAL:** This section should be high-level conceptual direction, NOT detailed requirements. If you're writing detailed features, user flows, or mockups, you've drifted into PRD territory.

### 2.1 Solution Ideas and Options
- **Purpose:** Present potential solution approaches
- **Content Requirements:**
  - Multiple solution options (at least 2-3)
  - Brief description of each approach (1-2 paragraphs each)
  - High-level pros/cons analysis
  - Feasibility assessment (general)
- **Format:** Numbered or bulleted list with sub-details
- **Keep It High-Level:** Describe the general approach, not specific features

**Example:**
```
Option 1: Enhanced Calendar View
Description: Build a dedicated compliance calendar with filtering capabilities
Pros: Faster to implement, addresses core pain point
Cons: Limited differentiation vs competitors
Feasibility: High - builds on existing infrastructure

Option 2: Full Compliance Platform
Description: Comprehensive system with workflows and automation
Pros: Best-in-class solution, strong differentiator
Cons: Longer timeline, higher complexity
Feasibility: Medium - requires new architecture
```

### 2.2 Chosen Solution Direction
- **Purpose:** Document the selected approach at a high level
- **Content Requirements:**
  - Clear statement of which option was chosen
  - High-level description of the solution (conceptual)
  - Core capabilities (bullet points, not detailed specs)
  - General approach and philosophy
- **Keep It Conceptual:** Describe "what kind of thing" you're building, not exact features

**Example:**
```
We will pursue a phased approach:

Phase 1: Unified Compliance Calendar
- Single view of all compliance obligations across entities
- Advanced filtering and search
- Automated notifications
- Basic reporting

The solution provides a centralized hub where users can see, filter, 
and track all compliance deadlines without navigating entity-by-entity.
```

### 2.3 Rationale
- **Purpose:** Explain why this direction was chosen
- **Content Requirements:**
  - Why this option over others
  - How it addresses the problem
  - Strategic alignment
  - Risk/reward balance
  - Feasibility considerations

**Example:**
```
This direction balances speed-to-value with long-term vision:
- Delivers core value quickly (8-10 weeks)
- Validates approach with users before larger investment
- Provides foundation for future enhancements
- Achieves competitive parity on critical capability
- Aligns with FY25 OKR for compliance strengthening
```

---

## What Comes Next: The PRD

After the discovery brief is approved (PM + UX sign-off), the next step is creating a **Product Requirements Document (PRD)** that includes:

### PRD Contents (NOT in Discovery Brief):
- **Detailed Functional Requirements:** Feature specifications, user stories, acceptance criteria
- **User Flows:** Step-by-step interaction flows created with Atlas Connector
- **UI/UX Designs:** Wireframes and mockups created with Atlas Connector
- **Technical Architecture:** System diagrams, data models, API specifications
- **Dependencies & Risks:** Detailed technical dependencies and mitigation plans
- **Success Metrics:** KPIs, measurement methods, target values
- **Implementation Plan:** Timeline, resource allocation, testing strategy
- **Rollout Strategy:** Phasing, feature flags, communication plan

### PRD Sign-offs:
PM + UX + ENG approval before proceeding to ticket breakdown

---

## Discovery Sign-offs

**Required:** Discovery briefs need PM and UX sign-off to proceed to PRD creation.

| Role | Name | Status |
|------|------|--------|
| **PM Sign-off** | @mention | ✓ or Pending |
| **UX Sign-off** | @mention | ✓ or Pending |

**Note:** Engineering reviews the PRD, not the discovery brief.

---

## Best Practices

### Writing Guidelines

1. **Be Concise and Clear**
   - Use simple, direct language
   - Avoid jargon unless necessary
   - Define acronyms on first use
   - Target 5-10 pages total

2. **Use Supporting Materials**
   - Link to user research (Dovetail)
   - Link to competitive analysis
   - Link to usage data/analytics
   - Include quotes and evidence

3. **Link to Strategic Context**
   - Reference strategic goals
   - Connect to product themes
   - Show business case
   - Explain urgency

4. **Keep It Updated**
   - Update Discovery Status as you progress
   - Add new insights as discovered
   - Document decision changes
   - Version significant updates

5. **Make It Scannable**
   - Use headers and sub-headers
   - Bullet points for lists
   - Bold key terms
   - Tables for structured data

### Common Patterns by Brief Type

#### **Feature Discovery Brief**
- Focus: New capability for users
- Emphasis: User needs, workflows, problem validation
- Heavy on: Problem discovery, user research
- Solution: High-level capability description

#### **Technical/Platform Brief**
- Focus: Infrastructure, architecture, technical debt
- Emphasis: Technical limitations and opportunities
- Heavy on: Problem validation, feasibility assessment
- Solution: High-level technical approach

#### **Integration Brief**
- Focus: Connecting systems/products
- Emphasis: Integration gaps and opportunities
- Heavy on: Current state analysis, compatibility needs
- Solution: High-level integration approach

#### **Modernization Brief**
- Focus: Updating existing functionality
- Emphasis: Current state analysis, user feedback
- Heavy on: Problem validation, migration considerations
- Solution: High-level modernization path

### Progressive Elaboration

Discovery briefs should grow through phases:

- **DRAFT:** Initial idea and context
- **PROBLEM DISCOVERY:** Complete Section 1 (problem validation)
- **SOLUTION DISCOVERY:** Complete Section 2 (explore options, choose direction)
- **COMPLETE:** Ready for PRD creation

### Quality Checklist

Before sign-off, verify:
- [ ] Problem is clearly stated and validated with evidence
- [ ] Target users/personas identified with pain points
- [ ] Evidence supports the problem (research, data, quotes)
- [ ] Opportunity size quantified (users, revenue, impact)
- [ ] Multiple solution options explored (2-3 options)
- [ ] Chosen solution direction explained (high-level)
- [ ] Rationale for chosen direction provided
- [ ] Strategic goal linked
- [ ] PM and UX tagged for sign-off
- [ ] Status is current and accurate

**Should NOT have:**
- [ ] Detailed functional requirements
- [ ] User flows or wireframes
- [ ] Technical architecture diagrams
- [ ] Implementation plans or timelines
- [ ] Detailed success metrics and KPIs

If your brief has these items, you've created a PRD, not a discovery brief. Remove the detailed content and create a separate PRD document.

---

## Templates and Examples

### Quick Start Template

Copy this template for a new discovery brief:

```
| **Discovery Status** | DRAFT |
| --- | --- |
| **Business Unit** | [Your BU] |
| **Product** | [Your Product] |
| **Assigned PM** | @[Your Name] |
| **Strategic Goal** | [Link] |

# 1. Problem Discovery

## 1.1 Problem Statement
[Describe the problem in 2-4 sentences]

## 1.2 Target Users, Personas & Pain Points
[Table with personas and their pain points]

## 1.3 Evidence & Insights
[User research, data, quotes supporting the problem]

## 1.4 Opportunity Size
[Quantify the impact - users affected, business value]

# 2. Solution Discovery

## 2.1 Solution Ideas and Options
1. [Option 1 - high level description, pros/cons]
2. [Option 2 - high level description, pros/cons]
3. [Option 3 - high level description, pros/cons]

## 2.2 Chosen Solution Direction
[High-level description of what you're building]

## 2.3 Rationale
[Why this direction? How does it solve the problem?]

# Discovery Sign-offs
| **PM Sign-off** | @[Name] | Pending |
| **UX Sign-off** | @[Name] | Pending |
```

### Example Titles
- "Discovery Brief: AI Evidence Collection Validation"
- "Discovery Brief: Compliance Calendar Problem & Direction"
- "Discovery Brief: Entities Modernization Approach"
- "Discovery Brief: Issue Listing Integration"

---

## Stopping at the Right Place

### Discovery Brief Stops Here:
✅ Problem validated with evidence
✅ User needs understood
✅ Opportunity sized
✅ Solution options explored (2-3)
✅ Direction chosen (high-level)
✅ Rationale explained
✅ PM + UX sign-off

### PRD Starts Here:
❌ Detailed functional requirements
❌ User flows and mockups
❌ Technical architecture
❌ Exact features and acceptance criteria
❌ Dependencies and risks
❌ Success metrics and measurement
❌ Implementation timeline
❌ Resource allocation
❌ Testing strategy

**If you're writing these things, you're writing a PRD, not a discovery brief.**

---

## Common Mistakes to Avoid

### Mistake 1: Combining Discovery Brief + PRD
**Problem:** Writing a 30-page document with everything from problem to implementation
**Solution:** Stop at solution direction. Create separate PRD for details.

### Mistake 2: Premature Design Work
**Problem:** Creating mockups and user flows during discovery
**Solution:** Save design work for PRD. Discovery brief is conceptual only.

### Mistake 3: Too Much Detail
**Problem:** Writing exact features, acceptance criteria, API specs
**Solution:** Keep it high-level. Details belong in PRD.

### Mistake 4: Skipping Options
**Problem:** Jumping straight to one solution without exploring alternatives
**Solution:** Always explore 2-3 options, then explain why you chose one.

### Mistake 5: Weak Problem Validation
**Problem:** Thin evidence, no user research, gut feeling only
**Solution:** Spend 70% of effort on problem validation. Get evidence.

---

## Appendices

### A. Common Acronyms
- PM: Product Manager
- UX: User Experience
- ENG: Engineering
- MVP: Minimum Viable Product
- POC: Proof of Concept
- PRD: Product Requirements Document
- D1P: Diligent One Platform

### B. Related Documentation
- PRD template: [Link to PRD skill/template]
- Strategic themes: [Link]
- Product roadmap: [Link]
- Discovery process guide: [Link]

### C. Revision History
| Date | Version | Changes | Author |
|------|---------|---------|--------|
| [Date] | 2.0 | Separated Discovery Brief from PRD | [Name] |

---

## Document Metadata

**Created:** [Date]
**Last Updated:** [Date]
**Owner:** Product Management
**Version:** 2.0 (Discovery Brief only, no PRD content)
**Status:** Active
